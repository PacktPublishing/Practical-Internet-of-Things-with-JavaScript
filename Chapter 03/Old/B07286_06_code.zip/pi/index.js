var config = require('./config.js');
var mqtt = require('mqtt');
var GetMac = require('getmac');
var moment = require('moment');
var request = require('request');

var raspi = require('raspi');
var I2C = require('raspi-i2c').I2C;

var Lcd = require('lcd'),
    lcd = new Lcd({
        rs: 12,
        e: 21,
        data: [5, 6, 17, 18],
        cols: 8,
        rows: 2
    });


var client = mqtt.connect({
    port: config.mqtt.port,
    protocol: 'mqtts',
    host: config.mqtt.host,
    clientId: config.mqtt.clientId,
    reconnectPeriod: 1000,
    username: config.mqtt.clientId,
    password: config.mqtt.clientId,
    keepalive: 300,
    rejectUnauthorized: false
});

client.on('connect', function() {
    client.subscribe('rpi');
    client.subscribe('socket');
    GetMac.getMac(function(err, mac) {
        if (err) throw err;
        macAddress = mac;
        client.publish('api-engine', mac);
    });
});

client.on('message', function(topic, message) {
    message = message.toString();
    if (topic === 'rpi') {
        console.log('API Engine Response >> ', message);
    } else {
        console.log('Unknown topic', topic);
    }
});

// infinite loop, with 3 seconds delay
setInterval(function() {
    readSensorValues(function(data) {

        var state = detectFall(data);

        var data2Send = {
            data: {
                acc: data,
                state: state
            },
            macAddress: macAddress
        };
        client.publish('accelerometer', JSON.stringify(data2Send));
    });
}, 3000); // every three second

// display time in row 1
setInterval(function() {
    var time = moment().tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss:SSS');
    lcd.on('ready', function() {
        lcd.setCursor(16, 0);
        lcd.autoscroll();
        printScroll('Now: ' + time);
    });
}, 1000); // update time every one second

function detectFall(data) {
    var state = 'free-falling';
    return state;
}

function displayLocation() {
    request('http://ipinfo.io', function(error, res, body) {
        console.log(JSON.parse(body));
        var info = JSON.parse(body);
        var text2Print = '';
        text2Print += 'City: ' + info.city;
        text2Print += ' Region: ' + info.region;
        text2Print += ' Country: ' + info.country;
        lcd.setCursor(16, 1); // 2nd row
        lcd.autoscroll();
        printScroll(text2Print);
    })
}

setInterval(function() {
    displayLocation();
}, 3600000); // check every hour

function readSensorValues(CB) {
    raspi.init(function() {
        var i2c = new I2C();
        var data = i2c.readByteSync(0x18);
        // need to validate this
        console.log('data', data); // Read one byte from the device at address 18
        if (CB) CB(data);
    });
}

// a function to print scroll
// http://thejackalofjavascript.com/rpi-16x2-lcd-print-stuff/
function printScroll(str, pos) {
    pos = pos || 0;

    if (pos === str.length) {
        pos = 0;
    }

    lcd.print(str[pos]);

    setTimeout(function() {
        print(str, pos + 1);
    }, 300);
}

// If ctrl+c is hit, free resources and exit.
process.on('SIGINT', function() {
    lcd.clear();
    lcd.close();
    process.exit();
});