import { Component, OnInit, OnDestroy } from '@angular/core';
import { DevicesService } from '../services/devices.service';
import { Params, ActivatedRoute } from '@angular/router';
import { SocketService } from '../services/socket.service';
import { DataService } from '../services/data.service';
import { NotificationsService } from 'angular2-notifications';

@Component({
	selector: 'app-device',
	templateUrl: './device.component.html',
	styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit, OnDestroy {
	device: any;
	data: Array<any>;
	toggleState: boolean = false;
	private subDevice: any;
	private subData: any;
	lastRecord: any;

	// line chart config
	public lineChartOptions: any = {
		responsive: true,
		legend: {
			position: 'bottom',
		}, hover: {
			mode: 'label'
		}, scales: {
			xAxes: [{
				display: true,
				scaleLabel: {
					display: true,
					labelString: 'Time'
				}
			}],
			yAxes: [{
				display: true,
				ticks: {
					beginAtZero: true,
					// steps: 10,
					// stepValue: 5,
					// max: 70
				}
			}]
		},
		title: {
			display: true,
			text: 'Sensor Data vs. Time'
		}
	};
	public lineChartLegend: boolean = true;
	public lineChartType: string = 'line';
	public xAxis: Array<any> = [];
	public yAxis: Array<any> = [];
	public zAxis: Array<any> = [];
	public lineChartLabels: Array<any> = [];

	constructor(private deviceService: DevicesService,
		private socketService: SocketService,
		private dataService: DataService,
		private route: ActivatedRoute,
		private notificationsService: NotificationsService) { }

	ngOnInit() {
		this.subDevice = this.route.params.subscribe((params) => {
			this.deviceService.getOne(params['id']).subscribe((response) => {
				this.device = response.json();
				this.getData();
				this.socketInit();
			});
		});
	}

	getData() {
		this.dataService.get(this.device.macAddress).subscribe((response) => {
			this.data = response.json();
			this.lastRecord = this.data[0]; // descending order data
			this.toggleState = this.lastRecord.data.s;
			this.genChart();
		});
	}

	socketInit() {
		this.subData = this.socketService.getData(this.device.macAddress).subscribe((data) => {
			if (this.data.length <= 0) return;
			this.data.splice(this.data.length - 1, 1); // remove the last record
			this.data.push(data); // add the new one
			this.lastRecord = data;
			this.toggleState = this.lastRecord.data.s;
			this.genChart();
		});
	}

	toggleChange(state) {
		let data = {
			macAddress: this.device.macAddress,
			data: {
				t: this.lastRecord.data.t,
				h: this.lastRecord.data.h,
				m: this.lastRecord.data.m,
				r: this.lastRecord.data.r,
				s: state ? 1 : 0
			},
			topic: 'socket'
		}

		this.dataService.create(data).subscribe((resp) => {
			if (resp.json()._id) {
				this.notificationsService.success('Device Notified!');
			}
		}, (err) => {
			console.log(err);
			this.notificationsService.error('Device Notification Failed. Check console for the error!');
		})
	}

	ngOnDestroy() {
		this.subDevice.unsubscribe();
		this.subData ? this.subData.unsubscribe() : '';
	}

	genChart() {
		let data = this.data;
		let _xArr: Array<any> = [];
		let _yArr: Array<any> = [];
		let _zArr: Array<any> = [];
		let _lblArr: Array<any> = [];

		let xArr: Array<any> = [];
		let yArr: Array<any> = [];
		let zArr: Array<any> = [];
		
		for (var i = 0; i < data.length; i++) {
			let _d = data[i];
			xArr.push(_d.data.x);
			yArr.push(_d.data.y);
			zArr.push(_d.data.z);
			_lblArr.push(this.formatDate(_d.createdAt));
		}

		// reverse data to show the latest on the right side
		xArr.reverse();
		yArr.reverse();
		zArr.reverse();
		_lblArr.reverse();

		_xArr = [
			{
				data: xArr,
				label: 'X-Axis (G)'
			},
			{
				data: yArr,
				label: 'Y-Axis (G)'
			}
		]

		_yArr = [
			{
				data: zArr,
				label: 'Z-Axis (G)'
			}
		]

		this.xAxis = _xArr;
		this.yAxis = _yArr;

		this.lineChartLabels = _lblArr;
	}

	private formatDate(originalTime) {
		var d = new Date(originalTime);
		var datestring = d.getDate() + "-" + (d.getMonth() + 1) + "-" + d.getFullYear() + " " +
			d.getHours() + ":" + d.getMinutes();
		return datestring;
	}

}