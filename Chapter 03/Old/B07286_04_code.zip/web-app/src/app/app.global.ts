// http://stackoverflow.com/a/39360585/1015046
export const Globals = Object.freeze({
	// BASE_API_URL: 'http://localhost:9000/',
	BASE_API_URL: 'https://add7231d.ngrok.io/',
	API_AUTH_TOKEN: 'AUTH_TOKEN',
	AUTH_USER: 'AUTH_USER'
});