import { Component, OnInit, OnDestroy } from '@angular/core';
import { DevicesService } from '../services/devices.service';
import { Params, ActivatedRoute } from '@angular/router';
import { SocketService } from '../services/socket.service';
import { DataService } from '../services/data.service';
import { NotificationsService } from 'angular2-notifications';
import { Globals } from '../app.global';

@Component({
	selector: 'app-device',
	templateUrl: './device.component.html',
	styleUrls: ['./device.component.css']
})
export class DeviceComponent implements OnInit, OnDestroy {
	device: any;
	data: Array<any>;
	toggleState: boolean = false;
	private subDevice: any;
	private subData: any;
	lastRecord: any;

	// line chart config

	constructor(private deviceService: DevicesService,
		private socketService: SocketService,
		private dataService: DataService,
		private route: ActivatedRoute,
		private notificationsService: NotificationsService) { }

	ngOnInit() {
		this.subDevice = this.route.params.subscribe((params) => {
			this.deviceService.getOne(params['id']).subscribe((response) => {
				this.device = response.json();
				this.getData();
			});
		});
	}

	getData() {
		this.dataService.get(this.device.macAddress).subscribe((response) => {
			this.data = response.json();
			let d = this.data[0];
			d.data.fname = Globals.BASE_API_URL + 'stream/' + d.data.fname;
			this.lastRecord = d; // descending order data
			this.socketInit();
		});
	}

	socketInit() {
		this.subData = this.socketService.getData(this.device.macAddress).subscribe((data: any) => {
			if (this.data.length <= 0) return;
			this.data.splice(this.data.length - 1, 1); // remove the last record
			data.data.fname = Globals.BASE_API_URL + 'stream/' + data.data.fname + '?t=' + (Math.random() * 100000); // cache busting
			this.data.push(data); // add the new one
			this.lastRecord = data;
		});
	}

	ngOnDestroy() {
		this.subDevice.unsubscribe();
		this.subData ? this.subData.unsubscribe() : '';
	}
}