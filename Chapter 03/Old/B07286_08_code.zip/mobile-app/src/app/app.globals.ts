// http://stackoverflow.com/a/39360585/1015046
export const Globals = Object.freeze({
	BASE_API_URL: 'http://10.2.192.220:9000/',
	// BASE_API_URL: 'http://192.168.1.3:9000/',
	API_AUTH_TOKEN: 'AUTH_TOKEN',
	AUTH_USER: 'AUTH_USER'
});